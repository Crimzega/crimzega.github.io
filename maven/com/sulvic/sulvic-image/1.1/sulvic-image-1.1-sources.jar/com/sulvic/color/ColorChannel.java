package com.sulvic.color;

import static com.sulvic.color.ColorHandler.KB;
import static com.sulvic.color.ColorHandler.KG;
import static com.sulvic.color.ColorHandler.KR;

import java.awt.Color;

public class ColorChannel{

	private double chrominanceBlue, chrominanceRed, luminance;

	public ColorChannel(double y, double cb, double cr){
		luminance = y;
		chrominanceBlue = cb;
		chrominanceRed = cr;
	}

	public static Color toColor(ColorChannel channel){
		double cb = channel.getChrominanceBlue(), cr = channel.getChrominanceRed(), lum = channel.getLuminance();
		double b = lum + (2d - 2d * KB) * cb, r = lum + (2d - 2d * KR) * cr;
		double g = (lum - KB * b - KR * r) / KG;
		return new Color(Math.max(0, Math.min(255, (int)Math.round(r))), Math.max(0, Math.min(255, (int)Math.round(g))), Math.max(0, Math.min(255, (int)Math.round(b))));
	}

	public double getChrominanceBlue(){ return chrominanceBlue; }

	public double getChrominanceRed(){ return chrominanceRed; }

	public double getLuminance(){ return luminance; }

}
