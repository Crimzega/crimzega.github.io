package com.sulvic.color;

import static com.sulvic.color.ColorHandler.to24Bit;

import java.awt.Color;

import com.sulvic.util.SulvicMath;

public class GameBoyAdvanceColor{

	private int blue, green, red;

	public GameBoyAdvanceColor(Color clr){ this(to4BPP(clr.getRed()), to4BPP(clr.getGreen()), to4BPP(clr.getBlue())); }

	public GameBoyAdvanceColor(int r, int g, int b){
		red = SulvicMath.clampInt(r, 0, 0x1F);
		green = SulvicMath.clampInt(g, 0, 0x1F);
		blue = SulvicMath.clampInt(b, 0, 0x1F);
	}

	public GameBoyAdvanceColor(float r, float g, float b){
		red = (int)(r * 0x1F);
		green = (int)(g * 0x1F);
		blue = (int)(b * 0x1F);
	}

	protected static int to4BPP(int value){ return (int)((value >> 3) & 0x1F); }

	public int getBlue(){ return blue; }

	public int getGreen(){ return green; }

	public int getRed(){ return red; }

	public Color asStoredColor(){ return new Color(to24Bit(red), to24Bit(green), to24Bit(blue)); }

}
