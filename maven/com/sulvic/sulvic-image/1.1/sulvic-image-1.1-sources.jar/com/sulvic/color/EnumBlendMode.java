package com.sulvic.color;

import static java.lang.Math.*;

/** An enum interpretation of jamieowen's glsl-blend GitHub repository.<br><a href="https://github.com/jamieowen/glsl-blend/">Repository</a> */
public enum EnumBlendMode{

	ADD,
	AVERAGE,
	COLOR_BURN,
	COLOR_DODGE,
	DARKEN,
	DIFFERENCE,
	EXCLUSION,
	GLOW,
	HARD_LIGHT,
	HARD_MIX,
	LIGHTEN,
	LINEAR_BURN,
	LINEAR_DODGE,
	LINEAR_LIGHT,
	MULTIPLY,
	NEGATION,
	NORMAL,
	OVERLAY,
	PHOENIX,
	PIN_LIGHT,
	REFLECT,
	SCREEN,
	SOFT_LIGHT,
	SUBTRACT,
	VIVID_LIGHT;

	public static EnumBlendMode byMethod(String method){
		for(EnumBlendMode mode: values()) if(mode.getMethod().equals(method)) return mode;
		return null;
	}

	public String getMethod(){ return name().toLowerCase(); }

	private double blendValue(double base, double blend){
		switch(this){
			case ADD: return min(base + blend, 1f);
			case AVERAGE: return (base + blend) / 2f;
			case COLOR_BURN: return blend == 0f? blend: max((1f - ((1f - base) / blend)), 0f);
			case COLOR_DODGE: return blend == 1f? blend: min(base / (1f - blend), 1f);
			case DARKEN: return min(blend, base);
			case DIFFERENCE: return abs(base - blend);
			case EXCLUSION: return base + blend - 2d * base * blend;
			case GLOW: return REFLECT.blendValue(base, blend);
			case HARD_LIGHT: return OVERLAY.blendValue(base, blend);
			case HARD_MIX: return VIVID_LIGHT.blendValue(base, blend) < 0.5d? 0d: 1d;
			case LIGHTEN: return max(blend, base);
			case LINEAR_BURN: return max(base + blend - 1d, 0d);
			case LINEAR_DODGE: return min(base + blend, 1d);
			case LINEAR_LIGHT: return blend < 0.5d? LINEAR_BURN.blendValue(base, 2d * blend): LINEAR_DODGE.blendValue(base, 2d * (blend - 0.5d));
			case MULTIPLY: return base * blend;
			case NEGATION: return 1d - abs(1d - base - blend);
			case OVERLAY: return base < 0.5d? 2d * base * blend: 1d - 2d * (1d - base) * (1d - blend);
			case PHOENIX: return min(base, blend) - max(base, blend) + 1d;
			case PIN_LIGHT: return blend < 0.5d? DARKEN.blendValue(base, 2d * blend): LIGHTEN.blendValue(base, 2d * (blend - 0.5d));
			case REFLECT: return blend == 1d? blend: min(base * base / (1d - blend), 1d);
			case SCREEN: return 1d - ((1d - base) * (1d - blend));
			case SOFT_LIGHT: return blend < 0.5d? 2d * base * blend + base * base * (1d - 2d * blend): sqrt(base) * (2d * blend - 1d) + 2d * base * (1d - blend);
			case SUBTRACT: return max(base + blend - 1d, 0d);
			case VIVID_LIGHT: return blend < 0.5d? COLOR_BURN.blendValue(base, 2d * blend): COLOR_DODGE.blendValue(base, 2d * (blend - 0.5d));
			default: return blend;
		}
	}

	private double blendValue(double base, double blend, double opacity){ return blendValue(base, blend) * opacity + base * (1f - opacity); }

	private double toRange(int value){ return (double)value / 255d; }

	public int blendColor(int rgbBase, int rgbBlend){
		double baseR = toRange((rgbBase >> 16) & 0xFF), baseG = toRange((rgbBase >> 8) & 0xFF), baseB = toRange(rgbBase & 0xFF);
		double blendR = toRange((rgbBlend >> 16) & 0xFF), blendG = toRange((rgbBlend >> 8) & 0xFF), blendB = toRange(rgbBlend & 0xFF);
		double newR = blendValue(baseR, blendR), newG = blendValue(baseG, blendG), newB = blendValue(baseB, blendB);
		return ((int)(newR * 0xFF) << 16) + ((int)(newG * 0xFF) << 8) + (int)(newB * 0xFF);
	}

	public int blendColor(int rgbBase, int rgbBlend, float opacity){
		double baseR = toRange((rgbBase >> 16) & 0xFF), baseG = toRange((rgbBase >> 8) & 0xFF), baseB = toRange(rgbBase & 0xFF);
		double blendR = toRange((rgbBlend >> 16) & 0xFF), blendG = toRange((rgbBlend >> 8) & 0xFF), blendB = toRange(rgbBlend & 0xFF);
		double newR = blendValue(baseR, blendR, opacity), newG = blendValue(baseG, blendG, opacity), newB = blendValue(baseB, blendB, opacity);
		return ((int)(newR * 0xFF) << 16) + ((int)(newG * 0xFF) << 8) + (int)(newB * 0xFF);
	}

}
