package com.sulvic.color;

import static com.sulvic.color.GameBoyAdvanceColor.to4BPP;

import java.awt.Color;

public class ColorHandler{

	protected static final double CB_MAX = 0.5d, CR_MAX = 0.5d, KB = 0.114d, KG = 1d, KR = 0.299d;

	protected static int to24Bit(int value){ return (value & 0x1F) << 3; }

	public static ColorChannel toColorChannel(Color clr){
		int b = clr.getBlue(), g = clr.getGreen(), r = clr.getRed();
		double lum = KR * r + KG * g + KB * b;
		double cb = CB_MAX * (b - lum) / (1 - KB), cr = CR_MAX * (r - lum) / (1 - KR);
		return new ColorChannel(lum, cb, cr);
	}

	public static GameBoyAdvanceColor toColorGBA(int r, int g, int b){ return new GameBoyAdvanceColor(to4BPP(r), to4BPP(g), to4BPP(b)); }

	public static GameBoyAdvanceColor toColorGBA(float r, float g, float b){ return new GameBoyAdvanceColor(r, g, b); }

	public static GameBoyAdvanceColor toColorGBA(Color color){ return new GameBoyAdvanceColor(color); }

}
