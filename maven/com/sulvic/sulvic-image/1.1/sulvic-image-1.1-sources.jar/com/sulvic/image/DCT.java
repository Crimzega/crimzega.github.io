package com.sulvic.image;

public class DCT{

	public static double[][] dct2D(double[][] coeffs){
		int rows = coeffs.length;
		int cols = coeffs[0].length;
		double[][] result = new double[rows][cols];
		for(int i = 0; i < rows; i++) result[i] = dct(coeffs[i]);
		for(int j = 0; j < cols; j++){
			double[] col = new double[rows];
			for(int i = 0; i < rows; i++) col[i] = result[i][j];
			double[] colDct = dct(col);
			for(int i = 0; i < rows; i++) result[i][j] = colDct[i];
		}
		return result;
	}

	public static double[] dct(double[] coeffs){
		int len = coeffs.length;
		double[] output = new double[len];
		for(int i = 0; i < len; i++){
			double sum = 0d;
			double alpha = Math.sqrt((i==0?1d:2d) / len);
			for(int j = 0; j < len; j++) sum += coeffs[j] * Math.cos((Math.PI * i * (2 * j + 1)) / (2d * len));
			output[i] = alpha * sum;
		}
		return output;
	}

	public static double[][] idct2D(double[][] coeffs){
		int rows = coeffs.length;
		int cols = coeffs[0].length;
		double[][] result = new double[rows][cols];
		for(int i = 0; i < rows; i++) result[i] = idct(coeffs[i]);
		for(int j = 0; j < cols; j++){
			double[] col = new double[rows];
			for(int i = 0; i < rows; i++) col[i] = result[i][j];
			double[] colDct = idct(col);
			for(int i = 0; i < rows; i++) result[i][j] = colDct[i];
		}
		return result;
	}

	public static double[] idct(double[] coeffs){
		int len = coeffs.length;
		double[] result = new double[len];
		for(int i = 0; i < len; i++){
			double sum = 0d;
			for(int j = 0; j < len; j++) {
				double alpha = Math.sqrt((j == 0? 1d: 2d) / len);
				sum += alpha * coeffs[j] * Math.cos((Math.PI * j * (2 * i + 1)) / (2d * len));
			}
			result[i] = sum;
		}
		return result;
	}

}
